plugins { id("com.android.application") }

android {
    namespace = "com.tamimcctv.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tamimcctv.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
