package com.tamimcctv.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String RED = "#E50914";
    private static final String DARK = "#0B0F14";
    private static final String CARD = "#151B22";
    private static final String WEBSITE = "https://tamim-cctv.netlify.app/";
    private static final String PHONE = "+8801927331873";
    private static final String WA = "8801927331873";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private TextView text(String s, float size, int color) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setPadding(16,12,16,12); return v;
    }
    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this); b.setText(label); b.setOnClickListener(l); return b;
    }
    private void base(LinearLayout root) { root.setOrientation(LinearLayout.VERTICAL); root.setPadding(16,16,16,16); root.setBackgroundColor(Color.parseColor(DARK)); }
    private ScrollView scroll(LinearLayout root) { ScrollView s = new ScrollView(this); s.addView(root); return s; }

    private void showHome() {
        LinearLayout root = new LinearLayout(this); base(root);
        TextView title = text("TAMIM CCTV & SECURITY", 26, Color.WHITE); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub = text("নিরাপত্তায় প্রযুক্তির বিশ্বস্ত সঙ্গী", 16, Color.parseColor(RED)); sub.setGravity(Gravity.CENTER); root.addView(sub);
        root.addView(text("CCTV ও Security Solutions — আপনার নিরাপত্তার জন্য।", 18, Color.WHITE));
        root.addView(button("📷  পণ্য দেখুন", v -> showProducts()));
        root.addView(button("💬  WhatsApp", v -> whatsapp("আসসালামু আলাইকুম, Tamim CCTV & Security থেকে পণ্য সম্পর্কে জানতে চাই।")));
        root.addView(button("📞  Call Now", v -> open("tel:" + PHONE)));
        root.addView(button("🌐  Website", v -> open(WEBSITE)));
        root.addView(text("জনপ্রিয় পণ্য", 22, Color.WHITE));
        addProduct(root, "IMOU Ranger 2 Pro", "Smart Wi-Fi Camera", "/imou-ranger-2-pro");
        addProduct(root, "Bullet & Dome Camera", "CCTV Camera", "");
        addProduct(root, "IP Camera", "Network Camera", "");
        addProduct(root, "DVR / NVR", "Recording", "");
        addProduct(root, "HDD & Storage", "Surveillance Storage", "");
        setContentView(scroll(root));
    }

    private void addProduct(LinearLayout root, String name, String category, String path) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(8,8,8,8); card.setBackgroundColor(Color.parseColor(CARD));
        card.addView(text(name, 18, Color.WHITE)); card.addView(text(category, 13, Color.LTGRAY));
        Button b = button("বিস্তারিত / দাম জানতে", v -> { if (!path.isEmpty()) open(WEBSITE + path); else whatsapp("আমি " + name + " সম্পর্কে জানতে চাই।"); }); card.addView(b); root.addView(card);
    }

    private void showProducts() {
        LinearLayout root = new LinearLayout(this); base(root);
        TextView h = text("Products", 28, Color.WHITE); root.addView(h);
        String[][] ps = {{"IMOU Ranger 2 Pro","Smart Wi-Fi Camera","/imou-ranger-2-pro"},{"Bullet & Dome Camera","CCTV Camera",""},{"IP Camera","Network Camera",""},{"DVR / NVR","Recording",""},{"HDD & Storage","Surveillance Storage",""},{"Power & UPS","Power Accessories",""},{"Cable & Connectors","Accessories",""},{"Networking","Switch / Router",""},{"Access & Door Security","Biometric / Smart Lock",""}};
        for (String[] p: ps) addProduct(root,p[0],p[1],p[2]);
        root.addView(button("← Home", v -> showHome())); setContentView(scroll(root));
    }

    private void open(String url) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch(Exception ignored) {} }
    private void whatsapp(String msg) { open("https://wa.me/" + WA + "?text=" + Uri.encode(msg)); }
}
