# Tamim CCTV & Security — Android App v1

Website: https://tamim-cctv.netlify.app/

এই ভার্সনে আপনার ওয়েবসাইটের বর্তমান Product/Package categories অ্যাপের Products তালিকায় যুক্ত করা হয়েছে:
- IMOU Ranger 2 Pro
- Bullet & Dome Camera
- IP Camera
- DVR / NVR
- HDD & Storage
- Power & UPS
- Cable & Connectors
- Networking
- Access & Door Security
- 4 / 8 / 16 Camera Packages

Contact:
- Phone/WhatsApp: 01927331873

IMOU Ranger 2 Pro-এর Website Details button সরাসরি:
https://tamim-cctv.netlify.app/imou-ranger-2-pro

Product photos পরে drawable/resources-এ যোগ করা যাবে।
