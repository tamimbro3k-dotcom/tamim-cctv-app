package com.tamimcctv.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val WHATSAPP_NUMBER = "8801927331873"
private const val PHONE_NUMBER = "+8801927331873"
private const val WEBSITE_URL = "https://tamim-cctv.netlify.app/"

private val Red = Color(0xFFE50914)
private val Dark = Color(0xFF0B0F14)
private val Card = Color(0xFF151B22)

data class Product(val name: String, val category: String, val price: String, val webPath: String = "")

private val products = listOf(
    Product("IMOU Ranger 2 Pro", "Smart Wi-Fi Camera", "দাম জানতে WhatsApp", "/imou-ranger-2-pro"),
    Product("Bullet & Dome Camera", "CCTV Camera", "দাম জানতে WhatsApp"),
    Product("IP Camera", "Network Camera", "দাম জানতে WhatsApp"),
    Product("DVR / NVR", "Recording", "দাম জানতে WhatsApp"),
    Product("HDD & Storage", "Surveillance Storage", "দাম জানতে WhatsApp"),
    Product("Power & UPS", "Power Accessories", "দাম জানতে WhatsApp"),
    Product("Cable & Connectors", "Accessories", "দাম জানতে WhatsApp"),
    Product("Networking", "Switch / Router", "দাম জানতে WhatsApp"),
    Product("Access & Door Security", "Biometric / Smart Lock", "দাম জানতে WhatsApp"),
    Product("4 Camera Package", "Starter Package", "Quote চাই"),
    Product("8 Camera Package", "Popular Package", "Quote চাই"),
    Product("16 Camera Package", "Business Package", "Quote চাই")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TamimApp() }
    }

    fun openUrl(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    fun call() = openUrl("tel:$PHONE_NUMBER")
    fun whatsapp(message: String = "আসসালামু আলাইকুম, Tamim CCTV & Security থেকে পণ্য সম্পর্কে জানতে চাই।") {
        openUrl("https://wa.me/$WHATSAPP_NUMBER?text=${Uri.encode(message)}")
    }
}

@Composable
fun TamimApp() {
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Product?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            background = Dark,
            surface = Card
        )
    ) {
        if (selected != null) {
            ProductDetails(selected!!) { selected = null }
        } else {
            Scaffold(
                containerColor = Dark,
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF10151B)) {
                        listOf(
                            Icons.Default.Home to "Home",
                            Icons.Default.ShoppingBag to "Products",
                            Icons.Default.LocalOffer to "Offers",
                            Icons.Default.Person to "Contact"
                        ).forEachIndexed { i, pair ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(pair.first, null) },
                                label = { Text(pair.second) }
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad)) {
                    when (tab) {
                        0 -> HomeScreen(
                            onProducts = { tab = 1 },
                            onProduct = { selected = it },
                            onWebsite = { (LocalContextHolder.current as MainActivity).openUrl(WEBSITE_URL) },
                            onWhatsapp = { (LocalContextHolder.current as MainActivity).whatsapp() }
                        )
                        1 -> ProductsScreen(onProduct = { selected = it })
                        2 -> OffersScreen(onWhatsapp = { (LocalContextHolder.current as MainActivity).whatsapp("আমি CCTV Package সম্পর্কে জানতে চাই।") })
                        else -> ContactScreen()
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onProducts: () -> Unit, onProduct: (Product) -> Unit, onWebsite: () -> Unit, onWhatsapp: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(com.tamimcctv.app.R.drawable.tamim_logo), null, Modifier.size(58.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("TAMIM", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text("CCTV & SECURITY", color = Red, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value = "", onValueChange = {}, enabled = false, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search products...") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(16.dp))
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2028)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("আপনার নিরাপত্তা", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("আমাদের অঙ্গীকার", fontSize = 25.sp, color = Red, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("CCTV ও Security Solutions — আপনার নিরাপত্তার জন্য।")
                Spacer(Modifier.height(14.dp))
                Button(onClick = onProducts) { Text("পণ্য দেখুন  →") }
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("ক্যাটাগরি", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(260.dp), userScrollEnabled = false, horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("📷 CCTV", "🎥 IP Camera", "🔐 DVR/NVR", "💾 Hard Disk", "🔌 Accessories", "🔥 Offers")) { c ->
                Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.clickable { onProducts() }) {
                    Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) { Text(c, fontSize = 14.sp) }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("জনপ্রিয় পণ্য", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("সব দেখুন", color = Red, modifier = Modifier.clickable { onProducts() })
        }
        Spacer(Modifier.height(10.dp))
        products.take(4).forEach { p ->
            ProductRow(p, onClick = { onProduct(p) })
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onWhatsapp, modifier = Modifier.weight(1f)) { Text("WhatsApp") }
            OutlinedButton(onClick = onWebsite, modifier = Modifier.weight(1f)) { Text("Website") }
        }
    }
}

@Composable
private fun ProductsScreen(onProduct: (Product) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Products", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("CCTV & Security Solutions", color = Color.LightGray)
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(products) { p ->
                Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().clickable { onProduct(p) }) {
                    Column(Modifier.padding(14.dp)) {
                        Box(Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF202832)), contentAlignment = Alignment.Center) {
                            Text("📷", fontSize = 40.sp)
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Text(p.category, color = Color.LightGray, fontSize = 12.sp)
                        Text(p.price, color = Red, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductRow(p: Product, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF202832)), contentAlignment = Alignment.Center) { Text("📷", fontSize = 30.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                Text(p.category, color = Color.LightGray, fontSize = 12.sp)
                Text(p.price, color = Red, fontWeight = FontWeight.Bold)
            }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

@Composable
private fun ProductDetails(p: Product, onBack: () -> Unit) {
    val activity = LocalContextHolder.current as MainActivity
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Product Details", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(20.dp)).background(Color.White), contentAlignment = Alignment.Center) {
            Text("PRODUCT PHOTO", color = Color.DarkGray, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(18.dp))
        Text(p.name, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
        Text(p.price, color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Key Features", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        listOf("High quality security solution", "Reliable performance", "Professional installation available", "Warranty / support as applicable").forEach {
            Text("✓  $it", modifier = Modifier.padding(top = 7.dp))
        }
        Spacer(Modifier.height(22.dp))
        Button(onClick = { activity.whatsapp("আমি ${p.name} অর্ডার করতে চাই।") }, modifier = Modifier.fillMaxWidth()) { Text("💬  WhatsApp দিয়ে অর্ডার করুন") }
        OutlinedButton(onClick = { activity.call() }, modifier = Modifier.fillMaxWidth()) { Text("📞  Call Now") }
        if (p.webPath.isNotBlank()) {
            OutlinedButton(
                onClick = { activity.openUrl(WEBSITE_URL.removeSuffix("/") + p.webPath) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("🌐  Website-এ বিস্তারিত দেখুন") }
        }
    }
}

@Composable
private fun OffersScreen(onWhatsapp: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("বিশেষ অফার", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Red), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("CCTV Package", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Camera + DVR/NVR + HDD + Cable + Installation", color = Color.White)
                Spacer(Modifier.height(14.dp))
                Button(onClick = onWhatsapp, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Red)) { Text("আজই অর্ডার করুন") }
            }
        }
    }
}

@Composable
private fun ContactScreen() {
    val activity = LocalContextHolder.current as MainActivity
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Contact Us", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        ContactCard("📞", "Call Us", PHONE_NUMBER) { activity.call() }
        ContactCard("💬", "WhatsApp", WHATSAPP_NUMBER) { activity.whatsapp() }
        ContactCard("🌐", "Website", WEBSITE_URL) { activity.openUrl(WEBSITE_URL) }
    }
}

@Composable
private fun ContactCard(icon: String, title: String, value: String, click: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { click() }) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 26.sp)
            Spacer(Modifier.width(14.dp))
            Column { Text(title, fontWeight = FontWeight.Bold); Text(value, color = Color.LightGray) }
        }
    }
}

/* Small composition-local holder so the starter stays compact. */
object LocalContextHolder {
    val current: android.content.Context
        @Composable get() = androidx.compose.ui.platform.LocalContext.current
}
