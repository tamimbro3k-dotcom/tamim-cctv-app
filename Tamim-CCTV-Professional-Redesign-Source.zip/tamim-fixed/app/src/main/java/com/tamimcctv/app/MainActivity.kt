package com.tamimcctv.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val WHATSAPP_NUMBER = "8801927331873"
private const val PHONE_NUMBER = "+8801927331873"
private const val WEBSITE_URL = "https://tamim-cctv.netlify.app/"
private const val FACEBOOK_URL = "https://www.facebook.com/share/1BgTHnVK99/"

private val Navy = Color(0xFF020B16)
private val Navy2 = Color(0xFF071827)
private val Card = Color(0xFF091D2D)
private val Border = Color(0xFF12456B)
private val Red = Color(0xFFFF1738)
private val White = Color(0xFFF6F8FC)
private val Muted = Color(0xFFB8CAE0)

private data class Tile(val title: String, val subtitle: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val color: Color)

private val tiles = listOf(
    Tile("CCTV Camera", "Installation & Setup", Icons.Default.Videocam, Color(0xFFFF1738)),
    Tile("Service", "Repair & Maintenance", Icons.Default.Build, Color(0xFF1976FF)),
    Tile("Networking", "LAN / WiFi Setup", Icons.Default.Lan, Color(0xFF00C878)),
    Tile("Access Control", "Biometric / RFID", Icons.Default.Lock, Color(0xFF7C3AED)),
    Tile("Products", "CCTV & Security Devices", Icons.Default.Inventory2, Color(0xFFFF8A00)),
    Tile("Gallery", "Our Work & Projects", Icons.Default.PhotoLibrary, Color(0xFFFF0B78)),
    Tile("Location", "Find Us on Map", Icons.Default.LocationOn, Color(0xFF00BFD8)),
    Tile("Contact", "Call / WhatsApp", Icons.Default.Phone, Color(0xFFFFB400))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TamimApp(this) }
    }

    fun openUrl(url: String) { runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }
    fun call() = openUrl("tel:$PHONE_NUMBER")
    fun whatsapp(message: String = "আসসালামু আলাইকুম, Tamim CCTV & Security থেকে সেবা/পণ্য সম্পর্কে জানতে চাই।") =
        openUrl("https://wa.me/$WHATSAPP_NUMBER?text=${Uri.encode(message)}")
}

@Composable
private fun TamimApp(activity: MainActivity) {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Navy, surface = Card)) {
        Scaffold(
            containerColor = Navy,
            bottomBar = { BottomNav(tab) { tab = it } }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when (tab) {
                    0 -> HomeScreen(activity) { tab = 1 }
                    1 -> ServicesScreen(activity)
                    2 -> GalleryScreen()
                    3 -> ContactScreen(activity)
                    else -> AboutScreen(activity)
                }
            }
        }
    }
}

@Composable
private fun Header(activity: MainActivity) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.tamim_logo), null, Modifier.size(66.dp), contentScale = ContentScale.Fit)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text("TAMIM", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Text("CCTV & SECURITY", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("Your Safety  Our Priority", color = Muted, fontSize = 10.sp)
        }
        IconButton(onClick = { activity.whatsapp() }) { Icon(Icons.Default.Notifications, null, tint = White) }
        IconButton(onClick = { activity.openUrl(WEBSITE_URL) }) { Icon(Icons.Default.Menu, null, tint = White) }
    }
}

@Composable
private fun HomeScreen(activity: MainActivity, onProducts: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Navy)) {
        Header(activity)
        Hero(activity)
        Spacer(Modifier.height(14.dp))
        TileGrid(activity, onProducts)
        Spacer(Modifier.height(16.dp))
        ServicesPreview(activity)
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun Hero(activity: MainActivity) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Navy2)
    ) {
        Box(Modifier.fillMaxWidth().height(290.dp)) {
            Image(
                painterResource(R.drawable.tamim_owner), null,
                Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                alpha = 0.9f
            )
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Navy.copy(alpha=.98f), Navy.copy(alpha=.72f), Color.Transparent))))
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Navy.copy(alpha=.45f)))))
            Column(Modifier.padding(start = 20.dp, top = 22.dp, end = 155.dp)) {
                Text("PROFESSIONAL CCTV & SECURITY SOLUTIONS", color = White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(12.dp))
                Text("Secure Your Home", color = White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text("& Business", color = Red, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(7.dp))
                Text("আপনার নিরাপত্তাই আমাদের অগ্রাধিকার", color = White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    CheckText("CCTV")
                    CheckText("Networking")
                }
                Spacer(Modifier.height(15.dp))
                Button(
                    onClick = { activity.whatsapp("আমি Tamim CCTV & Security-এর সার্ভিস সম্পর্কে জানতে চাই।") },
                    shape = RoundedCornerShape(30.dp), colors = ButtonDefaults.buttonColors(containerColor = Red)
                ) { Text("Learn More  →", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable private fun CheckText(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(18.dp).clip(CircleShape).background(Red), contentAlignment = Alignment.Center) { Text("✓", color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(5.dp)); Text(text, color = White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TileGrid(activity: MainActivity, onProducts: () -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4), modifier = Modifier.fillMaxWidth().height(410.dp).padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(8.dp), userScrollEnabled = false
    ) {
        items(tiles) { t ->
            Card(
                modifier = Modifier.fillMaxWidth().height(200.dp).clickable {
                    when (t.title) { "Contact" -> activity.call(); "Products" -> onProducts(); "Location" -> activity.openUrl("https://maps.google.com/?q=Kishoreganj,Bangladesh"); "Gallery" -> activity.openUrl(WEBSITE_URL); else -> activity.whatsapp("আমি ${t.title} সম্পর্কে জানতে চাই।") }
                }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Card)
            ) {
                Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Box(Modifier.size(50.dp).clip(CircleShape).background(t.color), contentAlignment = Alignment.Center) { Icon(t.icon, null, tint = White, modifier = Modifier.size(27.dp)) }
                    Spacer(Modifier.height(10.dp))
                    Text(t.title, color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(t.subtitle, color = Muted, fontSize = 8.sp, maxLines = 2)
                }
            }
        }
    }
}

@Composable
private fun ServicesPreview(activity: MainActivity) {
    Column(Modifier.padding(horizontal = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(5.dp).height(38.dp).clip(RoundedCornerShape(4.dp)).background(Red))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text("Our Services", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold); Text("Complete security solutions for your home & business.", color = Muted, fontSize = 10.sp) }
            Button(onClick = { activity.openUrl(WEBSITE_URL) }, shape = RoundedCornerShape(22.dp), contentPadding = PaddingValues(horizontal = 14.dp), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("View All →", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ServiceCard("CCTV Camera", "Installation", R.drawable.tamim_logo)
            ServiceCard("Networking", "Setup", R.drawable.tamim_logo)
            ServiceCard("Access Control", "System", R.drawable.tamim_logo)
            ServiceCard("Home & Office", "Security", R.drawable.tamim_logo)
        }
    }
}

@Composable
private fun ServiceCard(title: String, subtitle: String, image: Int) {
    Card(Modifier.weight(1f).height(145.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
        Column(Modifier.padding(7.dp)) {
            Image(painterResource(image), null, Modifier.fillMaxWidth().height(75.dp).clip(RoundedCornerShape(10.dp)).background(Navy2), contentScale = ContentScale.Fit)
            Spacer(Modifier.height(5.dp)); Text(title, color = White, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 9.sp)
        }
    }
}

@Composable private fun ServicesScreen(activity: MainActivity) { SimplePage("Services", "CCTV installation • Repair • Networking • Access Control", activity) }
@Composable private fun GalleryScreen() { SimplePage("Gallery", "Our CCTV & Security work and projects", null) }

@Composable
private fun ContactScreen(activity: MainActivity) {
    SimplePage("Contact Us", "Kishoreganj, Dhaka, Bangladesh", activity)
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.Center) {
        Spacer(Modifier.height(100.dp))
        ContactButton("📞  Call 01927331873") { activity.call() }
        ContactButton("💬  WhatsApp") { activity.whatsapp() }
        ContactButton("🌐  Website") { activity.openUrl(WEBSITE_URL) }
        ContactButton("📘  Facebook Page") { activity.openUrl(FACEBOOK_URL) }
    }
}

@Composable private fun AboutScreen(activity: MainActivity) { SimplePage("About Tamim CCTV", "Trusted CCTV & Security solutions for home, shop and office.", activity) }

@Composable
private fun SimplePage(title: String, subtitle: String, activity: MainActivity?) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Navy).padding(18.dp)) {
        Image(painterResource(R.drawable.tamim_logo), null, Modifier.size(82.dp), contentScale = ContentScale.Fit)
        Spacer(Modifier.height(12.dp)); Text(title, color = White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold); Text(subtitle, color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp)); Text("TAMIM CCTV & SECURITY", color = Red, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        if (activity != null) { Spacer(Modifier.height(18.dp)); ContactButton("💬  WhatsApp-এ যোগাযোগ করুন") { activity.whatsapp() }; ContactButton("📞  এখনই কল করুন") { activity.call() } }
    }
}

@Composable private fun ContactButton(text: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { onClick() }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
        Text(text, color = White, modifier = Modifier.padding(18.dp), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF061321), tonalElevation = 0.dp) {
        val items = listOf(
            Icons.Default.Home to "Home", Icons.Default.GridView to "Services", Icons.Default.PhotoLibrary to "Gallery", Icons.Default.Phone to "Contact", Icons.Default.Person to "About Us"
        )
        items.forEachIndexed { i, (icon, label) -> NavigationBarItem(selected = selected == i, onClick = { onSelect(i) }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Red, selectedTextColor = Red, unselectedIconColor = Muted, unselectedTextColor = Muted, indicatorColor = Color.Transparent)) }
    }
}
